<!DOCTYPE html>
<html lang="en">
  <!--head-->
  <?include 'head.php'?>
<body>
<!--presentacion-->
<?include'presentacion.php';?>
<!--menu-->
<?include'menu.php';?>

<div class="container" style="margin-top:30px">
  <div class="row">
    <div class="col-sm-4">
      <h2>Impacto</h2>
     
      <hr class="d-sm-none">
    </div>
    <div class="col-sm-8">
      <h2>Impactos</h2>
      <h5>10~10~2021</h5>
   <img src="img/brownies.jpg">
      <p>listado...</p>
      <p>surgimiento</p>
      <br>
      <h2>TITLE HEADING</h2>
      <h5>Title description, Sep 2, 2017</h5>
    
      <p>Some text..</p>
      <p>Sunt in culpa qui officia deserunt mollit anim id est laborum consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.</p>
    </div>
  </div>
</div>

<div class="jumbotron text-center" style="margin-bottom:0">
  <p>Footer</p>
</div>

</body>
</html>
