<div class="col-sm-8">
      <h2>Visión</h2>
      <p>Establecernos como competencia importante en el mercado actual de servicio al cliente, brindando desde nuestros inicios la mejor calidad para seguir satisfaciendo los mas profundos deseos de una gran población</p>
      <br>
</div>
