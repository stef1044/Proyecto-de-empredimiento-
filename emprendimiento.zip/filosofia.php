<div>
<h2>Filosofía</h2>
      <p>inmarcesibles ante el caos de la vida , viendo los problemas como la oportunidad de ser mejor</p>
    </div>