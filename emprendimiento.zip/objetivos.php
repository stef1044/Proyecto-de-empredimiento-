<!DOCTYPE html>
<html lang="en">
  <!--head-->
  <?include 'head.php'?>
<body>
<!--presentacion-->
<?include'presentacion.php';?>
<!--menu-->
<?include'menu.php';?>

<div class="container" style="margin-top:30px">
  <div class="row">
    <div class="col-sm-4">
      <h2>Objetivos</h2>
     
      <hr class="d-sm-none">
    </div>
    <div class="col-sm-8">
      <h2>objetivos</h2>
      <h5>20~07~2019</h5>
   <img src="img/tacos.jfif">
      <p>listado...</p>
      <p>Todo sobre nuentro comienzo.</p>
      <br>
      <h2>TITLE HEADING</h2>
      <h5>Title description, Sep 2, 2017</h5>
    
      <p>Some text..</p>
      <p>hace algun tiempo siendo tan jovenes e inquietos habitaba en nosotros ese deseo de independencia por lo cual se nos hizo indispensable la idea de nuestro propio negocio fue asi como nacio la idea de representarnos explosivamente en dulces innovando en el mercado..</p>
    </div>
  </div>
</div>

</body>
</html>

      </ul>
      <hr class="d-sm-none">
    </div>
    <div class="col-sm-8">





      
      
      <div class="fakeimg">Fake Image</div>
      <p>Some text..</p>
      <p>hace algun tiempo siendo tan jovenes e inquietos habitaba en nosotros ese deseo de independencia por lo cual se nos hizo indispensable la idea de nuestro propio negocio fue asi como nacio la idea de representarnos explosivamente en dulces innovando en el mercado..</p>
    </div>
  </div>
</div>

<div class="jumbotron text-center" style="margin-bottom:0">
  <p>Footer</p>
</div>

</body>
</html>
