<!DOCTYPE html>
<html lang="en">
  <!--head-->
  <?include 'head.php'?>
<body>
<!--presentacion-->
<?include'presentacion.php';?>
<!--menu-->
<?include'menux.php';?>

<div class="container">
  <div class="row">
    <div class="col-sm-4">
      <h2>Productos Dulci splot</h2>
     
      <hr class="d-sm-none">
    </div>
    <div class="col-sm-8">

      <!--Dulces explosivos-->
      <h2>No te quedes con las ganas de :3 </h2>
      
      <h5>Galletas dinamita</h5>
      <img src="img/galletas 2.jpg" height="250" width="250">
      
      <h5>Chocolates splot</h5>
      
      <img src="img/chocolates1.jpg" height="250" width="250">
      
      <h5> brownies explosivos </h5>
      <img src="img/brown1.jpg" height="250" width="250">
      <p><h4>¿De que estan hechos nuestros productos?</h4>
        
      <h2>Galletas dinamita</h2>
       <h5>precio: 2.000 </h5>
      <img src="img/galletas 1.jpg" height="250" width="250">
       <table border="1"><TR>
         <TD colspan=2>informacion nutricional</TD>
         <TD> Tamaño de la porción:26 g de mezcla
           porciones por envase:20</TD>
         <TD>cantidad por porción:
         proteinas
         grasas (lipidos)
           de las cuales:
           grasa saturada
           carbohidratos
           (hidratos de carbono)
           de los cuales:
           azucares
           fibra dietica
           sodio
         <TD><TD> harina
         420kJ
         (99 kcal)
         menos de 1g
         0.5 g
         22 g
         15 g
         menos de 1 g
         80 mg<TD> <TD>preparado</TD></TD>
       </TR>
         
       </table> 
      
   
     
      <br>
      <br>
      <!--Para todos los fanáticos del chocolate y de las cosas ricas, aquí les dejo la receta ideal.-->
      
      <h2> Chocolates Splot </h2>
     <h5>precio: (en proceso) </h5>
      <img src="img/chocolate3.png" height="250" width="250">
        
     <p><h4>Ingredientes...</h4>
      <p> 
        - Aceite de Coco <br>
        - Cacaco amargo en polvo <br>
        - Almendras<br>
        - Esencia de menta<br>

 <p><h4>Dato curioso </h4>
      <p> los chocolates Splot son nombrados de esta forma ya que son la especialidad de Mrs. Splot nuestro querido panadero ruso.
        
 <!-- dato curioso: los chocolates Splot son nombrados de esta forma ya que son la especialidad de Mrs. Splot nuestro querido panadero ruso.-->

      <br>
      <!--brownies-->
      <h2> Brownies explosivos</h2>
      
      <h5>precio:  5.000$</h5>
       <img src="img/brownie4.jpg" height="250" width="250">
     
 
        
   (los ingredientes son esclusivos de nuestra marca) <br>
 
        
        Todos nuestros productos llevan nuestra magia explosiva y estos brownies no son la excepcion ;) <br>

    </div>
  </div>
</div>
 <?
include 'footer.php';
?>
</body>
</html>

