<div class="jumbotron text-center" style="margin-bottom:0">
  <h1>Mi presentación</h1>
  <p>¡Bienvenidos lindosss!</p> 
</div>