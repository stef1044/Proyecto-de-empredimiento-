<!DOCTYPE html>
<html lang="en">
  <!--head-->
  <?include 'head.php';?>
<body>
  <?
include 'publicidad.php'
?>
<!--presentacion-->


<!--menu-->
<?
include'menu.php'
?>

<div class="container">
  <div class="row">
    <div class="col-sm-4">
      <h2>About us</h2>
      <h5>breeders</h5>
      <div class="fakeimg"><img src="img/socias.jpg" height="200" width="350"></div>
      <p> llenar el mundo con nuestra magia explosiva , cambiando vidas , creando sabor</p>
      <h3>Contactanos</h3>
      <ul class="nav nav-pills flex-column">
        <li class="contacts">
          <a class="contactss" href="#">WhastApp</a>
        </li>
        <li class="contacts">
          <a class="contactss" href="#">Facebook</a>
        </li>
        <li class="contacts">
          <a class="contactss" href="#">Instagram</a>
        </li>
      </ul>
      <hr class="d-sm-none">
    </div>
<div class="col-sm-8">
    <?
include 'vision.php'
?>
<?
include 'mision.php'
?>
<?
include 'filosofia.php'
?>

 <?
include 'footer.php';
?>
</div>
  </div>
</div>
</body>
</html>


