<div>
<h2>Misión</h2>
      <p>Nos esforzamos por destacarnos con la calidad de nuestros productos, en una búsqueda constante de innovación sin decaer la calidad que nos caracteriza. Estamos comprometidos a fortalecer continuamente nuestros productos para establecer una posición en el mercado actual.</p>
    </div>