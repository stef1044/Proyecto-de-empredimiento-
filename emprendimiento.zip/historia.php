<!DOCTYPE html>
<html lang="en">
  <!--head-->
  <?include 'head.php'?>
<body>
<!--presentacion-->
<?include'presentacion.php';?>
<!--menu-->
<?include'menu.php';?>

<div class="container" style="margin-top:30px">
  <div class="row">
    <div class="col-sm-4">
      <h2>Nuestros Rostros</h2>
      <br>
         <img src="img/socias.jpg" width="200" height="200">
     
      <hr class="d-sm-none">
    </div>
    <div class="col-sm-8">
      <h2>DkciSplot</h2> 
      
      <h5> Nuestro proyecto comenzó con un fuerte deseo de generar ingresos para alcanzar nuestra independización. Para encontrar un lugar mejor qué habitar.

Pensamos en qué podríamos hacer para alcanzar este sueño y sin pensarlo este estaba delante de nosotros , siempre nos ha gustado mucho los dulces y de aquí surgió nuestra idea "DulciSplot" (nuestros dulces explosivos) , decidimos empezar haciendo galletas , luego se nos ocurrió los brownies y chocolates y fue así como vimos una gran oportunidad de salir adelante y compartir nuestros productos con todos
        
        <p> 
          - Por Luisa Perez y Stefany muñoz 
        </p>
      </h5>
    </div>
  </div>
</div>

</body>
</html>
  <?
include 'footer.php';
?>
